// Aquano public configuration. Publishable key is designed for browser use; never put service_role here.
window.AQUANO_CONFIG = {
  supabaseUrl: 'https://wwvtwrzolvumlmiortpp.supabase.co',
  supabaseKey: 'sb_publishable_Ly2UWlBTuIje3jfR-fR2Mg_uB5QX03Q'
};
