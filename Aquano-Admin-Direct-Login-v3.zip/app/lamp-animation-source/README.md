# Lamp Login Animation — interactive recreation

## Run
Open `index.html` in a modern browser. Drag the lamp's pull cord downward (or tap/click it) to reveal the login panel. Use **Hide login** to reset the scene.

## Files
- `index.html` — page structure
- `style.css` — responsive layout, lamp illustration, glow and reveal animations
- `script.js` — drag/touch/click interaction, password visibility and demo form behavior

## Important
This is a front-end recreation inspired by the supplied screen recording, not the original creator's source code. Sign-in, password recovery, registration and social login are demo interactions only; no credentials are sent or stored. Connect a secure backend/OAuth provider to enable real authentication.
