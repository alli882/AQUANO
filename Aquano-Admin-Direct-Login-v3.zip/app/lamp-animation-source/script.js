const scene = document.querySelector(".scene");
const lampPull = document.querySelector("#lampPull");
const lampShade = document.querySelector("#lampShade");
const loginCard = document.querySelector("#loginCard");
const sceneCaption = document.querySelector("#sceneCaption");
const resetScene = document.querySelector("#resetScene");

let pointerStartY = null;
let pullDistance = 0;
let awakened = false;

function revealLogin() {
  if (awakened) return;
  awakened = true;
  scene.classList.add("is-awake");
  loginCard.classList.remove("is-hidden");
  loginCard.setAttribute("aria-hidden", "false");
  sceneCaption.innerHTML = '<span class="caption-line"></span> WELCOME TO YOUR WORKSPACE <span class="caption-line"></span>';
  resetScene.hidden = false;
}

function resetLamp() {
  awakened = false;
  pullDistance = 0;
  scene.classList.remove("is-awake");
  loginCard.classList.add("is-hidden");
  loginCard.setAttribute("aria-hidden", "true");
  sceneCaption.innerHTML = '<span class="caption-line"></span> PULL THE LIGHT TO BEGIN <span class="caption-line"></span>';
  resetScene.hidden = true;
  lampPull.style.transform = "";
  lampShade.style.marginTop = "";
}

lampPull.addEventListener("pointerdown", (event) => {
  if (awakened) return;
  pointerStartY = event.clientY;
  pullDistance = 0;
  lampPull.setPointerCapture(event.pointerId);
});
lampPull.addEventListener("pointermove", (event) => {
  if (pointerStartY === null || awakened) return;
  pullDistance = Math.max(0, Math.min(100, event.clientY - pointerStartY));
  lampPull.style.transform = `translateY(${pullDistance}px)`;
  lampShade.style.marginTop = `${Math.min(16, pullDistance * 0.12)}px`;
  if (pullDistance > 58) revealLogin();
});
lampPull.addEventListener("pointerup", () => {
  if (pointerStartY !== null && pullDistance > 28) revealLogin();
  pointerStartY = null;
  if (!awakened) {
    lampPull.style.transform = "";
    lampShade.style.marginTop = "";
  }
});
lampPull.addEventListener("pointercancel", () => {
  pointerStartY = null;
  if (!awakened) {
    lampPull.style.transform = "";
    lampShade.style.marginTop = "";
  }
});
// Keyboard accessibility: focus the pull control and press Enter or Space.
lampPull.addEventListener("click", () => revealLogin());
lampPull.addEventListener("keydown", (event) => {
  if (event.key === "Enter" || event.key === " ") revealLogin();
});
resetScene.addEventListener("click", resetLamp);

const form = document.querySelector("#loginForm");
const message = document.querySelector("#formMessage");
const password = document.querySelector("#password");
const showPassword = document.querySelector(".show-password");

showPassword.addEventListener("click", () => {
  const showing = password.type === "text";
  password.type = showing ? "password" : "text";
  showPassword.setAttribute("aria-label", showing ? "Show password" : "Hide password");
  showPassword.title = showing ? "Show password" : "Hide password";
});

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const username = document.querySelector("#username").value.trim();
  if (!username || !password.value) {
    message.textContent = "Please enter your username and password.";
    return;
  }
  message.textContent = "Demo mode: connect an authentication service to sign in.";
});

document.querySelector("#forgotLink").addEventListener("click", (event) => {
  event.preventDefault();
  message.textContent = "Password recovery would be connected to your account service.";
});
document.querySelector("#signupLink").addEventListener("click", (event) => {
  event.preventDefault();
  message.textContent = "Account creation would open your registration page.";
});
document.querySelectorAll(".social-button").forEach((button) => {
  button.addEventListener("click", () => {
    message.textContent = `${button.dataset.provider} sign-in is a visual demo; configure OAuth to enable it.`;
  });
});
