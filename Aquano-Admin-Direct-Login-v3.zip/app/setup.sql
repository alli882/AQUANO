-- Aquano-New: safe setup additions for the supplied schema.
-- Run in Supabase SQL Editor. Does not drop or recreate existing tables.
-- Admin access is read from trusted app_metadata.role; never let clients edit app_metadata.

create or replace function public.is_admin()
returns boolean language sql stable security invoker set search_path = '' as $$
  select coalesce((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin', false);
$$;

-- Admins can manage products and categories. Public read policies already exist in this project.
drop policy if exists "Aquano admins manage products" on public.products;
create policy "Aquano admins manage products" on public.products
for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "Aquano admins manage categories" on public.categories;
create policy "Aquano admins manage categories" on public.categories
for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Admins can inspect orders and order lines. Existing customer read policies remain intact.
drop policy if exists "Aquano admins read orders" on public.orders;
create policy "Aquano admins read orders" on public.orders
for select to authenticated using (public.is_admin());
drop policy if exists "Aquano admins read order items" on public.order_items;
create policy "Aquano admins read order items" on public.order_items
for select to authenticated using (public.is_admin());

-- Atomic order request. No payment is initiated by this function.
create or replace function public.aquano_create_order(p_items jsonb, p_address jsonb)
returns uuid language plpgsql security definer set search_path = '' as $$
declare
  v_user uuid := auth.uid(); v_order uuid; v_subtotal numeric := 0; v_item jsonb;
  v_product public.products%rowtype; v_qty integer;
begin
  if v_user is null then raise exception 'برای ثبت سفارش وارد حساب شوید'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then raise exception 'سبد خرید خالی است'; end if;
  for v_item in select value from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::integer;
    if v_qty < 1 or v_qty > 100 then raise exception 'تعداد محصول نامعتبر است'; end if;
    select * into v_product from public.products where id = (v_item->>'product_id')::uuid and is_active = true for update;
    if not found then raise exception 'یکی از محصولات در دسترس نیست'; end if;
    if v_product.stock < v_qty then raise exception 'موجودی محصول کافی نیست: %', v_product.name; end if;
    v_subtotal := v_subtotal + v_product.price * v_qty;
  end loop;
  insert into public.orders(user_id,status,subtotal,shipping_fee,total,address_snapshot)
  values(v_user,'pending',v_subtotal,0,v_subtotal,p_address) returning id into v_order;
  for v_item in select value from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::integer;
    select * into v_product from public.products where id = (v_item->>'product_id')::uuid for update;
    insert into public.order_items(order_id,product_id,product_name,unit_price,quantity)
    values(v_order,v_product.id,v_product.name,v_product.price,v_qty);
    update public.products set stock = stock - v_qty, updated_at = now() where id = v_product.id;
  end loop;
  return v_order;
end; $$;
revoke all on function public.aquano_create_order(jsonb,jsonb) from public;
grant execute on function public.aquano_create_order(jsonb,jsonb) to authenticated;

-- IMPORTANT: Before opening admin panel, create a user in Supabase Auth, then assign
-- app_metadata.role = 'admin' to that user from a trusted server/admin environment.
-- Never expose the service_role key in config.js or browser code.
